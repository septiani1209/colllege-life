<?php
    include "koneksi.php";

    $sql = "CREATE TABLE user(
        id int PRIMARY KEY,
        nama varchar(50),
        major varchar(50),
        university varchar(50),
        dateofbirth varchar(30),
        email varchar(50)
    )";

    if($koneksi->query($sql) === TRUE){
        echo "Table berhasil dibuat ";
    }else{
        echo "Table gagal dibuat";
    }
?>