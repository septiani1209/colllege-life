<?php
    include "koneksi.php";

    $sql = "SELECT * FROM user";
    $result = $koneksi->query($sql);

    foreach($result as $result){
        $id = $result["id"];
        $nama = $result["nama"];
        $major = $result["major"];
        $university = $result["university"];
        $dateofbirth = $result["dateofbirth"];
        $email = $result["email"];
    }
?>