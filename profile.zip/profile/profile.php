<!DOCTYPE html>
<?php 
    include "show-data.php";
    include "update-data.php";
?>
<html>

<head>
    <title> My Profile</title>
    <meta name="viewport" content="width-device-width,
    initial-scale-1.0">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <section id="box-profile">
        <div class="img-profile">
            <div class="photo" style="background-image: 
            url(assets/img/profile.png);"></div>
        </div>
        <div class="description">
            <h1 id="pNama"><?php echo $nama; ?></h1>
        </div>
        <div class="information">
            <div class="data">
                <p class="field">Major</p>
                <p id="pMajor" class="text-gray"><?php echo $major; ?></p>
            </div>
            <div class="data">
                <p class="field">University</p>
                <p id="pUniversity" class="text-gray"><?php echo $university; ?></p>
            </div>
            <div class="data">
                <p class="field">Date of birth</p>
                <p id="pDateofbirth" class="text-gray"><?php echo $dateofbirth; ?></p>
            </div>
            <div class="data">
                <p class="field">Email</p>
                <p id="pEmail" class="text-gray"><?php echo $email; ?></p>
            </div>

            <a href="#input-form" class="button bg-purple" onclick="editForm()">Edit Profile</a>
        </div>
    </section>

    <section id="input-form">
        <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <div class="form">
                <input id="inpIdUser" type="text" name="id_user" value="<?php echo $id;?>">
            </div>
            <div class="form">
                <input id="inpNama" type="text" name="nama" placeholder="Nama">
            </div>
            <div class="form">
                <input id="inpMajor" type="major" name="major" placeholder="Major">
            </div>
            <div class="form">
                <input id="inpUniversity" type="university" name="university" placeholder="University">
            </div>
            <div class="form">
                <input id="inpDateofbirth" type="dateofbirth" name="dateofbirth" placeholder="Date of Birth">
            </div>
            <div class="form">
                <input id="inpEmail" type="email" name="email" placeholder="Email">
            </div>
            <div class="form">
                <input onclick="" type="submit" name="submit" value="SAVE" class="bg-purple">
            </div>
        </form>
    </section>

    <script>
    var formMenu = document.getElementById("input-form");
    formMenu.style.display = "none";

    function editForm() {
        if (formMenu.style.display === "none") {
            formMenu.style.display = "block";
        } else {
            formMenu.style.display = "none";
        }

        var nama = document.getElementById("pNama").innerHTML;
        var major = document.getElementById("pMajor").innerHTML;
        var university = document.getElementById("pUniversity").innerHTML;
        var dateofbirth = document.getElementById("pDateofbirth").innerHTML;
        var email = document.getElementById("pEmail").innerHTML;

        document.getElementById("inpNama").value = nama;
        document.getElementById("inpMajor").value = major;
        document.getElementById("inpUniversity").value = university;
        document.getElementById("inpDateofbirth").value = dateofbirth;
        document.getElementById("inpEmail").value = email;
    }

    function simpanForm() {
        formMenu.style.display = "none"
        var nama = document.getElementById("inpNama").value;
        var major = document.getElementById("inpMajor").value;
        var university = document.getElementById("inpUniversity").value;
        var dateofbirth = document.getElementById("inpDateofbirth").value;
        var email = document.getElementById("inpEmail").value;

        document.getElementById("pName").innerHTML = nama;
        document.getElementById("pMajor").innerHTML = major;
        document.getElementById("pUniversity").innerHTML = university;
        document.getElementById("pDateofbirth").innerHTML = dateofbirth;
        document.getElementById("pEmail").innerHTML = email;
    }
    </script>
</body>

</html>