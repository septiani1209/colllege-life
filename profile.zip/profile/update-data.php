<?php
    include "koneksi.php";

    if(isset($_POST['submit'])){
        $id_user = $_POST["id_user"];
        $nama = $_POST["nama"];
        $major = $_POST["major"];
        $university = $_POST["university"];
        $dateofbirth = $_POST["dateofbirth"];
        $email = $_POST["email"];

        $sql = " UPDATE user SET nama = '$nama', major = '$major', university = '$university', dateofbirth = '$dateofbirth', email = '$email' WHERE id = $id_user";
        
        if($koneksi->query($sql) == TRUE){
            
        }else {
            echo "Update data gagal";
        }
    }


?>