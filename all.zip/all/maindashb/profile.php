<!DOCTYPE html>
<?php 
    include "show-data.php";
    include "update-data.php";
    // include "includes/function.php";
    include "header.php";

    if(!isset($_SESSION['email'])){
        header("location : index.php");
    }

    
    ?>
<html>
    
    <head>
        
        <title> My Profile</title>
        <meta name="viewport" content="width-device-width,
        initial-scale-1.0">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/profile.css">

    
</head>

<body>
    <?php echo "header.php" ?>
    <section id="box-profile">
        <div class="shows">
        <div class="img-profile">
            <div class="photo">
                <img class='prof' src="users/<?php echo "$user_img"; ?>" alt="profile" name="user_image">
            </div>
        </div>
        <!-- <div class="description"> -->
            <!-- </div> -->
        <div class="information">
            <h1 id="pNama">@<?php echo $user_name; ?></h1>
            <div class="data">
                <p class="field">Name</p>
                <p id="pNama" class="text-gray"><?php echo $nama; ?></p>
            </div>
            <div class="data">
                <p class="field">Major</p>
                <p id="pMajor" class="text-gray"><?php echo $major; ?></p>
            </div>
            <div class="data">
                <p class="field">University</p>
                <p id="pUniversity" class="text-gray"><?php echo $university; ?></p>
            </div>
            <!-- <div class="data">
                <p class="field">Date of birth</p>
                <p id="pDateofbirth" class="text-gray"><?php //echo $dateofbirth; ?></p>
            </div> -->
            <!-- <div class="data">
                <p class="field">Email</p>
                <p id="pEmail" class="text-gray"><?php //echo $email; ?></p>
            </div> -->
            
            <div class="edits">
                <!-- <a href="#input-form" class="button bg-purple" onclick="editForm()">Edit Profile</a> -->
                <button  id="open" class="button bg-purple" onclick="modals()">Edit Profile</button>
            </div>
        <!-- </div> -->
        </div>
        </div>
    </section>

    <div class="maindash">
            <div class="dashb">
                <!-- <center><h2><strong>DASHBOARD</strong></h2><br></center> -->
                <?php echo get_posts(); ?>
            </div>
    </div>
    
    <div class="modal-container" id="modal_container">
        <div class="modal">
            <div class="clsbtn">
                <button id="close">
                        <i class='bx bx-x'></i>
                </button>
            </div>
            <div class="wrapper">  
                <section id="input-form">
                    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                        <div class="form">
                            <input class="editfield" id="inpUsername" type="text" name="username" value="<?php echo $user_name;?>">
                        </div>
                        <div class="form">
                            <input class="editfield" id="inpNama" type="text" name="nama" placeholder="Nama" value="<?php echo $nama;?>">
                        </div>
                        <div class="form">
                            <input class="editfield" id="inpMajor" type="major" name="major" placeholder="Major" value="<?php echo $major;?>">
                        </div>
                        <div class="form">
                            <input class="editfield" id="inpUniversity" type="university" name="university" placeholder="University" value="<?php echo $university;?>">
                        </div>
                        <div class="form">
                            <input class="editfield" id="inpDateofbirth" type="dateofbirth" name="dateofbirth" placeholder="Date of Birth" value="<?php echo $dateofbirth;?>">
                        </div>
                        <div class="form">
                            <input class="editfield" id="inpEmail" type="email" name="email" placeholder="Email" value="<?php echo $email;?>">
                        </div>
                        <div class="form">
                            <input onclick="" type="submit" name="submit" value="SAVE" class="bg-purple">
                        </div>
                    </form>
                </section>
            </div>
        </div>
    </div>

    <script>
    // var formMenu = document.getElementById("input-form");
    // formMenu.style.display = "none";

    function editForm() {
        // if (formMenu.style.display === "none") {
        //     formMenu.style.display = "block";
        // } else {
        //     formMenu.style.display = "none";
        // }

        var nama = document.getElementById("pNama").innerHTML;
        var major = document.getElementById("pMajor").innerHTML;
        var university = document.getElementById("pUniversity").innerHTML;
        var dateofbirth = document.getElementById("pDateofbirth").innerHTML;
        var email = document.getElementById("pEmail").innerHTML;

        document.getElementById("inpNama").value = nama;
        document.getElementById("inpMajor").value = major;
        document.getElementById("inpUniversity").value = university;
        document.getElementById("inpDateofbirth").value = dateofbirth;
        document.getElementById("inpEmail").value = email;
    }

    function simpanForm() {
        formMenu.style.display = "none"
        var nama = document.getElementById("inpNama").value;
        var major = document.getElementById("inpMajor").value;
        var university = document.getElementById("inpUniversity").value;
        var dateofbirth = document.getElementById("inpDateofbirth").value;
        var email = document.getElementById("inpEmail").value;

        document.getElementById("pName").innerHTML = nama;
        document.getElementById("pMajor").innerHTML = major;
        document.getElementById("pUniversity").innerHTML = university;
        document.getElementById("pDateofbirth").innerHTML = dateofbirth;
        document.getElementById("pEmail").innerHTML = email;
    }


    function modals(){
    const open = document.getElementById('open');
    const modal_container = document.getElementById('modal_container');
    const close = document.getElementById('close');

    open.addEventListener('click', () => {
        modal_container.classList.add('show')
    });
            
    close.addEventListener('click', () => {
        modal_container.classList.remove('show')
    });
    }
    </script>
</body>

</html>