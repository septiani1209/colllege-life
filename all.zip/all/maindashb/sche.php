<?php 
include("header.php"); ?>

<!DOCTYPE html>
<html>

<head>
<?php
		$user = $_SESSION['email'];
		$get_user = "select * from users where email='$user'";
		$run_user = mysqli_query($con,$get_user);
		$row = mysqli_fetch_array($run_user);

		$user_name = $row['username'];
        $user_img = $row['profpic'];
        // $user_id = $row['user_id'];
?>

<link rel="stylesheet" href="fullcalendar/fullcalendar.min.css" />
<script src="fullcalendar/lib/jquery.min.js"></script>
<script src="fullcalendar/lib/moment.min.js"></script>
<script src="fullcalendar/fullcalendar.min.js"></script>

<!-- <meta charset="utf-8"> -->
<!-- <meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
<title>Schedule</title>
<!-- <link rel="stylesheet" href="css/sche.css"> -->
<!-- <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'> -->
<!-- <link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/left.css"> -->

        

<script>

$(document).ready(function () {
    var calendar = $('#calendar').fullCalendar({
        editable: true,
        events: "calendfunc/fetch-event.php",
        displayEventTime: false,
        eventRender: function (event, element, view) {
            if (event.allDay === 'true') {
                event.allDay = true;
            } else {
                event.allDay = false;
            }
        },
        selectable: true,
        selectHelper: true,
        select: function (start, end, allDay) {
            var title = prompt('Event Title:');

            if (title) {
                var start = $.fullCalendar.formatDate(start, "Y-MM-DD HH:mm:ss");
                var end = $.fullCalendar.formatDate(end, "Y-MM-DD HH:mm:ss");

                $.ajax({
                    url: 'calendfunc/add-event.php',
                    data: 'title=' + title + '&start=' + start + '&end=' + end,
                    type: "POST",
                    success: function (data) {
                        displayMessage("Added Successfully");
                    }
                });
                calendar.fullCalendar('renderEvent',
                        {
                            title: title,
                            start: start,
                            end: end,
                            allDay: allDay
                        },
                true
                        );
            }
            calendar.fullCalendar('unselect');
        },
        
        editable: true,
        eventDrop: function (event, delta) {
                    var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
                    var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");
                    $.ajax({
                        url: 'calendfunc/edit-event.php',
                        data: 'title=' + event.title + '&start=' + start + '&end=' + end + '&id=' + event.id,
                        type: "POST",
                        success: function (response) {
                            displayMessage("Updated Successfully");
                        }
                    });
                },
        eventClick: function (event) {
            var deleteMsg = confirm("Do you really want to delete?");
            if (deleteMsg) {
                $.ajax({
                    type: "POST",
                    url: "calendfunc/delete-event.php",
                    data: "&id=" + event.id,
                    success: function (response) {
                        if(parseInt(response) > 0) {
                            $('#calendar').fullCalendar('removeEvents', event.id);
                            displayMessage("Deleted Successfully");
                        }
                    }
                });
            }
        }

    });
});

function displayMessage(message) {
	    $(".response").html("<div class='success'>"+message+"</div>");
    setInterval(function() { $(".success").fadeOut(); }, 1000);
}
</script>

<style>
body {
    /* margin-top: 50px; */
    text-align: center;
    font-family: "Poppins", sans-serif;
}



#calendar {
    font-size: 12px;
    margin-top: 20px;
    padding: 10px;
    background-color: #F6F4FC;
    /* border: solid 0.1px #7E53DB; */
    border-radius: 5px;
    width: 600px;
    /* height: 100%; */
    /* margin: 0 auto; */
    margin-left: 345px;
    box-shadow: 1px 1px  rgba(0, 0, 0, 0.2);
    position: relative;
    /* z-index: -1; */
}

.fc-event{
border: 1px solid #7E53DB;
}

.fc-event, .fc-event-dot{
    background: #7E53DB;
}

.response {
    height: 15px;
    margin-top: 9px;
}

.success {
    background: #cdf3cd;
    padding: 3px 60px;
    border: #c3e6c3 1px solid;
    display: inline-block;
}






</style>

</head>

<body>

    



    <!-- <h2>PHP Calendar Event Management FullCalendar JavaScript Library</h2> -->

    <div class="response"></div>
    <div id='calendar'></div>
</body>

</html>