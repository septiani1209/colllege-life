<?php 

$server = "localhost";
$user = "root";
$pass = "";
$database = "college_life";

$con = mysqli_connect($server, $user, $pass, $database) or die("Connection was not established"); 

if(isset($_POST['query'])){

    $data = array();
    $condition = preg_replace('/[^A-Za-z0-9\- ]/', '', $_POST['query']);

    $query = "
    select username from users where username like '%".$condition."%' order by user_id desc limit 10
    ";

    $result = $con->query($query);
    $replace_string = '<b>'.$condition.'</b>';

    foreach($result as $row){
        $data[] = array(
            'username' => str_ireplace($condition, $replace_string, $row['username'])
        );
    }

    echo json_encode($data);

}