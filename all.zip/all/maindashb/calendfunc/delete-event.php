<?php
require_once "../connect.php";

$id = $_POST['id'];
$sqlDelete = "DELETE from schedule WHERE id=".$id;

mysqli_query($con, $sqlDelete);
echo mysqli_affected_rows($con);

mysqli_close($con);
?>