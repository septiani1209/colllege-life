<?php
require_once "../connect.php";

$title = isset($_POST['title']) ? $_POST['title'] : "";
$start = isset($_POST['start']) ? $_POST['start'] : "";
$end = isset($_POST['end']) ? $_POST['end'] : "";
// $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : "";

$sqlInsert = "INSERT INTO schedule (title,start,end) VALUES ('".$title."','".$start."','".$end ."')";

$result = mysqli_query($con, $sqlInsert);

if (! $result) {
    $result = mysqli_error($con);
}
?>