<?php 

session_start();

(include "connect.php");

// session_start();
// error_reporting(0);

function logIn(){
    global $con;


    if (isset($_POST['submit'])) {

		$email = htmlentities(mysqli_real_escape_string($con, $_POST['email']));
		$pass = htmlentities(mysqli_real_escape_string($con, $_POST['password']));

		$select_user = "select * from users where email='$email' AND pass='$pass' AND status='verified'";
		$query= mysqli_query($con, $select_user);
		$check_user = mysqli_num_rows($query);

		if($check_user == 1){
			$_SESSION['email'] = $email;

			echo "<script>window.open('dashboard.php', '_self')</script>";
		}else{
			echo"<script>alert('Your Email or Password is incorrect')</script>";
		}
	}
    
    // session_start();
    
    // if (isset($_SESSION['username'])) {
    //     header("Location: ../Dashboard/index.html");
    // }

    // if (isset($_POST['submit'])) {
    //     $email = $_POST['email'];
    //     $password = md5($_POST['password']);
        
    //     $sql = "SELECT * FROM users WHERE email='$email' AND pass='$password'";
    //     $result = mysqli_query($con, $sql);
    //     if ($result->num_rows > 0) {
    //         $row = mysqli_fetch_assoc($result);
    //         $_SESSION['email'] = $row['email'];
    //         header("Location: ../Dashboard/index.html");
    //         echo "<script>window.open('dashboard.php', '_self')</script>";
    //     } else {
    //         echo "<script>alert('Woops! Email or Password is Wrong.')</script>";
    //     }
    // }
    
    // include("includes/connection.php");
    
	
}

function register(){
    global $con;
    // session_start();

        
    if (isset($_POST['submitR'])) {
            $username = htmlentities(mysqli_real_escape_string($con,$_POST['username']));
            $email = htmlentities(mysqli_real_escape_string($con,$_POST['email']));
            $pass = htmlentities(mysqli_real_escape_string($con,$_POST['password']));
            $status = "verified";
		    $posts = "no";
            $profile_pic = "profile.png";
            // $username = $_POST['username'];
            // $email = $_POST['email'];
            // $password = md5($_POST['password']);
            // $cpassword = md5($_POST['cpassword']); 

            if(strlen($pass) < 9 ){
                echo"<script>alert('Password should be minimum 9 characters!')</script>";
                exit();
            }

            $check_username = "select * from users where username='$username'";
		    $run_username = mysqli_query($con,$check_username);
		    $check2 = mysqli_num_rows($run_username);

            $check_email = "select * from users where email='$email'";
		    $run_email = mysqli_query($con, $check_email);
		    $check = mysqli_num_rows($run_email);

		    if($check == 1){
			    echo "<script>alert('Email already exist, Please try using another email')</script>";
			    echo "<script>window.open('login.php', '_self')</>";
			    exit();
            }

		    if($check2 == 1){
			    echo "<script>alert('Username already exist, Please try another username')</script>";
			    echo "<script>window.open('login.php', '_self')</script>";
			    exit();
                }


            $insert = "insert into users (username, email, pass, status, posts, profpic) values('$username', '$email', '$pass', '$status', '$posts', '$profile_pic')";
            
            $query = mysqli_query($con, $insert);
            
            if($query){
                echo "<script>alert('Well Done $username, you are good to go.')</script>";
                echo "<script>window.open('login.php', '_self')</script>";
            }
            else{
                echo "<script>alert('Registration failed, please try again!')</script>";
                echo "<script>window.open('login.php', '_self')</script>";
            }
        }
    

}
?>