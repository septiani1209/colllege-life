<!DOCTYPE html>
<?php 

// include('includes/function.php');
include "header.php";

if(!isset($_SESSION['email'])){
    header("location : index.php");
}

?>

<html>
<head>
    <title>View Post</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/left.css">
    <link rel="stylesheet" href="css/single.css">
</head>
<body>

    <div class="maindashb">
        <div class="dashb">
            <center class="heads">
                bu
                <i class='bx bx-chevron-left'></i>
                <h2>Comments</h2>
            
            </center>
            <?php single_post(); ?>
        </div>
    </div>
</body>


</html>