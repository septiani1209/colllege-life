<?php
    include "connect.php";
   


    if(isset($_POST['submit'])){
        $user_name = $_POST["username"];
        $nama = $_POST["nama"];
        $major = $_POST["major"];
        $university = $_POST["university"];
        $dateofbirth = $_POST["dateofbirth"];
        $email = $_POST["email"];

        $sql = " UPDATE users SET nama = '$nama', major = '$major', university = '$university', dateofbirth = '$dateofbirth', email = '$email' WHERE username = '$user_name'";
        
        if($con->query($sql) == TRUE){
            
        }else {
            echo "Update data gagal";
        }
    }


?>