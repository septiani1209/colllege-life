<?php 
include("includes/function.php");
include("fetchcomment.php");
include("percobaan/finduname.php");
// include("logout.php");

// session_start();

// if(!isset($_SESSION['email'])){
// }

?>

<!DOCTYPE html>
<html>
    <head>

        <?php
		$user = $_SESSION['email'];
		$get_user = "select * from users where email='$user'";
		$run_user = mysqli_query($con,$get_user);
		$row = mysqli_fetch_array($run_user);

		$user_name = $row['username'];
		$user_id = $row['user_id'];
        $user_img = $row['profpic'];
        $nama = $row['nama'];
        $major = $row['major'];
        $university = $row['university'];
        $dateofbirth = $row["dateofbirth"];
        $email = $row['email'];
	    ?>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
        <title><?php echo "$user_name"; ?></title>
        <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> -->
        <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->

        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" /> -->
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/left.css">
        <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        
        
    </head>

    <body>
        <nav class="flex-div">
            <div class="nav-left">
                <img src="png/logos.png">
            </div>
            
            <div class="nav-middle flex-div">
                    <ul style="list-style: none;">
                        <li>
                            <div class="search-box flex-div">
                                <form method="post" class="finduser" style="position:relative">
                                    <input type="text" placeholder="Search" onkeyup="javascript:load_data(this.value)" name="search_user" required>
                                    <a href="searchresult.php">
                                    <!-- <button type="submit" name="search_user_btn" class="btn-find" style="background-color: transparent;  cursor:pointer; align-items:center; border:transparent;" id="btnsr" onclick="searchResult()"> -->
                                        <i class='bx bx-search' style='color:#4f3b8f; font-size:18px; vertical-align: middle;'></i>
                                    <!-- </button> -->
                                    </a>
                                    <!-- <i class='bx bx-search' style='color:#4f3b8f'></i> -->
                                    <!-- <img src="png/iconsearch.png"> -->
                                </form>
                                
                                
                            <!-- autocomplete -->
                            
                            </div>
                        </li>
                        <li>
                            <span id="search_result"></span>
                            </li>
                            </ul>
            </div>  

            <div class="nav-right flex-div">
                <!-- <button class="notify">
                    <i class='bx bxs-bell'></i> -->
                    <li class="dropdown" id="notifdrop" onclick="openNotif()">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <span class="label label-pill label-danger count" style="border-radius:10px;"></span> 
                        <i class='bx bxs-bell'></i>
                    </a>
                        <ul class="dropdown-menu" id="dropdownotif">
                            
                        </ul>
                    </li>
                    
                <!-- </button> -->
                <!-- <img src="png/notif.png" class="notify"> -->
                <a href="profile.php">
                 <img src="users/<?php echo "$user_img"; ?>">
                </a>
            </div>
                        
        </nav><br>
        <!-- <div id="sresult"> -->
        
        <!-- </div> -->
        
                    
                    

            <!---------------------sidebar--------------->
            
            <div class="sidebar">
                <ul class="nav-links">
                    <li> 
                        <a href="profile.php">
                            <i class='bx bxs-user'></i>
                            <span class="link-name">Profile</span>
                        </a>
                    </li>
                    <li>
                        <a href="dashboard.php">
                            <i class='bx bxs-home'></i>
                            <span class="link-name">Dashboard</span>
                        </a>   
                    </li>
                    <li>
                        <a href="sche.php">
                            <i class='bx bxs-calendar'></i>
                            <span class="link-name">Schedule</span>
                        </a>
                    </li>
                    
                    <li>
                        <div class="iocn-link"> 
                            <a href="">
                                <i class='bx bxs-trophy'></i>
                                <span class="link-name">Event</span>
                            </a>
                            <i class='bx bxs-chevron-down arrow' style="cursor: pointer;"></i>
                        </div>
                        <ul class="sub-menu">
                            <li><a href="#">Scholarship</a></li>
                            <!-- <li><a href="#">Volunteer</a></li> -->
                            <li><a href="#">Seminar</a></li>
                        </ul>
                    </li>
                    <li>
                        <div class="profile-details">   
                            <div class="profile-content">
                                <a href="profile.php">
                                <img src="users/<?php echo "$user_img"; ?>" alt="profile" name="user_image">
                                </a>
                            </div>'
                            <div class="name-job">
                                <a href="profile.php">
                                <div class="profile_name"><?php echo "$user_name"; ?></div>
                                </a>
                            </div>

                            <button id="logOpen" class="logout" onclick="logpop()">
                                <i class='bx bx-log-out'></i>
                            </button>
                            <div class="modal-logout" id="modal_logout">
                                <div class="logouts">
                                    <div class="hlog">
                                        <!-- <div class="closbtn"> -->
                                            <!-- </div> -->
                                            <p class="tlog">Do you want to log out?</p>
                                            <button id="logClose">
                                                <i class='bx bx-x' style="color: #4f3b8f;"></i>
                                            </button>
                                    </div>
                                    <div class="wraps">
                                        <button class="logs lNo">No</button>
                                        <button class="logs lYes">Yes</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>

    <script type="text/javascript">

            let arrow = document.querySelectorAll(".arrow");
            for(var i = 0; i < arrow.length; i++){
            arrow[i].addEventListener("click",(e)=>{
            let arrowParent = e.target.parentElement.parentElement;
            console.log(arrowParent);
            arrowParent.classList.toggle("showMenu");
            });
            }


            function showPreview(event){
            if(event.target.files.length > 0){
                var src = URL.createObjectURL(event.target.files[0]);
                var preview = document.getElementById("file-preview");
                preview.src = src;
                preview.style.display = "block";
            }
            }


            function load_data(query){
            if(query.length > 2){

            var form_data = new FormData();

            form_data.append('query', query);
            var ajax_request = new XMLHttpRequest();

            ajax_request.open('POST', 'search.php');

            ajax_request.send(form_data);

            ajax_request.onreadystatechange = function(){
                if(ajax_request.readyState == 4 && ajax_request.status == 200){
                    var response = JSON.parse(ajax_request.responseText);

                    var html = '<div class="list-group" style="position:absolute; margin-top:1px; border: solid 1px; border-bottom: transparent; border-radius:5px; width:520px; background: white; margin-left:10px;">';

                    if(response.length > 0){
                        for(var count = 0; count<response.length; count++){
                            html += '<a href="profile.php?username=$username" class="list-group-item list-group-item-action" style="display: block; border-bottom: solid 1px; padding: 3px;">'+response[count].username+'</a>';
                        }
                    }
                    else{
                        html += '<a href="#" class="list-group-item list-group-item-action disable">No Data Found</a>';
                    }
                    html += '</div>';

                    document.getElementById('search_result').innerHTML = html;
                }
             }
                }
                else{

                    document.getElementById('search_result').innerHTML='';

                }
            }

            function logpop(){
            const opens = document.getElementById('logOpen');
            const modal_logout = document.getElementById('modal_logout');
            const closes = document.getElementById('logClose');
            var schedules = document.getElementById('calendar');
            
            opens.addEventListener('click', () => {
                modal_logout.classList.add('showPop')
                schedules.style.zIndex = -1;
            });
            
            closes.addEventListener('click', () => {
                modal_logout.classList.remove('showPop')
                schedules.style.zIndex = 0;
            });
            }
        
            function openNotif(){
            const notif = document.getElementById('notifdrop');
            const dropnotif = document.getElementById('dropdownotif');
            notif.addEventListener('click', () => {
                dropnotif.classList.add('open')
                // schedules.style.zIndex = 0;
            });
        }
        
            // function searchResult(){
            // const btnsr = document.getElementById('btnsr');
            // const sr = document.getElementById('sr');
            // btnsr.addEventListener('click', () => {
            //     sr.classList.add('srOpen')
            //     // schedules.style.zIndex = 0;
            // });
            // }

        
            $(document).ready(function(){
 
            function load_unseen_notification(view = '')
            {
            $.ajax({
            url:"fetchcomment.php",
            method:"POST",
            data:{view:view},
            dataType:"json",
            success:function(data)
            {
                $('.dropdown-menu').html(data.notification);
                if(data.unseen_notification > 0)
                {
                $('.count').html(data.unseen_notification);
                }
                        }
            });
            }
            
            load_unseen_notification();
            
            
            $(document).on('click', '.dropdown-toggle', function(){
            $('.count').html('');
            load_unseen_notification('yes');
            });
            
            setInterval(function(){ 
            load_unseen_notification(); 
            }, 5000);
            
            });


        </script>
</body>
</html>