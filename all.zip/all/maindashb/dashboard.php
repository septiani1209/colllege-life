<?php 
// include("includes/function.php");
include("header.php");
// include("logout.php");

// session_start();

// if(!isset($_SESSION['email'])){
// }

?>

<!DOCTYPE html>
<html>
    <head>

        <?php
		$user = $_SESSION['email'];
		$get_user = "select * from users where email='$user'";
		$run_user = mysqli_query($con,$get_user);
		$row = mysqli_fetch_array($run_user);

		$user_name = $row['username'];
        $user_img = $row['profpic'];
	    ?>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo "$user_name"; ?></title>
        <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> -->
        <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->

        <!-- <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/left.css"> -->
        <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        
        
    </head>

    <body>
        
            
            
            <!-- Post Field -->
            <button id="open" class="open" onclick="addpost()">🚀  ADD  POST</button>
            
            
            <div class="modal-container" id="modal_container">
                <div class="modal">
                    <div class="clsbtn">
                    <button id="close">
                        <i class='bx bx-x'></i>
                    </button>
                    </div>
                <!-- <h1>modal</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat, atque? Nesciunt, dolor quidem enim ratione repellat illum sint blanditiis voluptatem facere perferendis nulla molestiae aperiam dicta accusamus, repudiandae placeat culpa.</p> -->
                <!-- <div class="container"> -->
                    <ul class="wrapper">
                        <form action="dashboard.php?id=<?php echo $user_id; ?>" method="post" id="f" enctype="multipart/form-data">  
                            <li> 
                                <div class="upload">
                                    <div class="add-img">
                                        <input type="file" name="upload_image" id="file" size="30" accept="image/*" onchange="showPreview(event);">
                                        <label id="imgbtn" for="file" style="text-align: center; vertical-align: middle;">
                                            <i class='bx bxs-image-add' style='color:#4f3b8f; font-size:20px; vertical-align:middle; '></i> &nbsp;
                                        </label>
                                        <div class="preview">
                                            <img id= "file-preview" src="" alt="">
            
                                            <input type="file" name="change_image" id="file" size="30" accept="image/*" onchange="showPreview(event);">
                                            <label id="changeImg" for="file" style="text-align: center; vertical-align: middle;"> Change Image </label>
                                            
                                        </div>
                                    </div>
                                </div>
                            </li>
        
                            <!-- archive -->
                            <li>
                                <div class="upload">
                                    <div class="arc-type">
                                        <label style="font-size: 13px; padding-right : 8px;">Type : </label>
                                        <select name="category">
                                            <option value="">-- Select ---</option>
                                            <option value="Portofolio">Portofolio</option>
                                            <option value="Certificate">Certificate</option>
                                            <option value="General">etc.</option>
                                        </select>
                                        <!-- <input type="submit" name="insert" value="INSERT DATA"> -->
                                    </div>
                                </div>
                            </li>
                                
                            <li> 
                                <div id="insert_post"  class="upload">
                                    <div class="add-capt">
                                        <textarea class="form-control" name="content" id="content" rows="4" placeholder="Post your achievement"></textarea><br>
                                    </div>
                                </div>
                            </li>
                                
                            <li> 
                                <div class="upload">
                                    <div class="submit">
                                        <button type="submit" class="btn-sub" name="sub">
                                            <i class='bx bxs-paper-plane'></i>
                                            <span>Post</span>
                                        </button>
                                    </div>
                                </div>
                            </li>     
                        </form>
                        <?php insertPost(); ?>
                    </ul>
                <!-- </div> -->
            </div>
        </div>

        
        

        <div class="maindash">
            <div class="dashb">
                <!-- <center><h2><strong>DASHBOARD</strong></h2><br></center> -->
                <?php echo get_posts(); ?>
            </div>
        </div>

        <script type="text/javascript">


            function showPreview(event){
            if(event.target.files.length > 0){
                var src = URL.createObjectURL(event.target.files[0]);
                var preview = document.getElementById("file-preview");
                preview.src = src;
                preview.style.display = "block";
                var btns = document.getElementById("imgbtn");
                btns.style.display = "none";
                var btnChange = document.getElementById("changeImg");
                btnChange.style.display = "block"
            }
            }



            function addpost(){
            const open = document.getElementById('open');
            const modal_container = document.getElementById('modal_container');
            const close = document.getElementById('close');

            open.addEventListener('click', () => {
                modal_container.classList.add('show')
            });
            
            close.addEventListener('click', () => {
                modal_container.classList.remove('show')
            });
            }
        </script>

        
    </body>
</html>