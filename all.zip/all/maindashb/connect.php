<?php 

$server = "localhost";
$user = "root";
$pass = "";
$database = "college_life";

$con = mysqli_connect($server, $user, $pass, $database) or die("Connection was not established"); ?>
