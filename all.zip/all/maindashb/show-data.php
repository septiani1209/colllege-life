<?php
    include "connect.php";

    
    $sql = "SELECT * FROM users";
    $result = $con->query($sql);

    foreach($result as $result){
        $user_img = $result["profpic"];
        $username = $result["username"];
        $nama = $result["nama"];
        $major = $result["major"];
        $university = $result["university"];
        $dateofbirth = $result["dateofbirth"];
        $email = $result["email"];
    }
?>