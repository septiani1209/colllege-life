<?php 

$con = mysqli_connect("localhost", "root", "college_life");

$category = $_POST['category']


?>