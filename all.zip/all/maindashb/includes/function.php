<?php

// $con = mysqli_connect("localhost","root","","college_life") or die("Connection was not established");
include("connect.php");

session_start();

$user = $_SESSION['email'];
$get_user = "select * from users where email='$user'";
$run_user = mysqli_query($con,$get_user);
$row = mysqli_fetch_array($run_user);

$user_id = $row['user_id'];

// $user_id = '22';

function insertPost(){
	if(isset($_POST['sub'])){
		global $con;
		global $user_id;
		
		$content = htmlentities($_POST['content']);
		$category = $_POST['category'];
		$upload_image = $_FILES['upload_image']['name'];
		$image_tmp = $_FILES['upload_image']['tmp_name'];
		$random_number = rand(1, 100);


		if(strlen($content) > 250){
			echo "<script>alert('Please Use 250 or less than 250 words!')</script>";
			echo "<script>window.open('dashboard.php', '_self')</script>";
			
		}
		
		else{
			if(strlen($upload_image) >= 1 && strlen($content) >= 1){
				if (($category) == ''){
					echo "<script>alert('Please Select Category')</script>";
					echo "<script>window.open('dashboard.php', '_self')</script>";
				}

				else{
				move_uploaded_file($image_tmp, "imagepost/$upload_image.$random_number");
				$insert = "insert into posts (user_id, post_content, upload_image, category, post_date) values('$user_id','$content', '$upload_image.$random_number', '$category', NOW())";
				// $insert2 ="insert into categorypost (arch_id, upload_image) values('$category','$upload_image.$random_number')";

				$run = mysqli_query($con, $insert);
				// $run2 = mysqli_query($con, $insert2);

				if($run){
					echo "<script>alert('Your Post updated a moment ago!')</script>";
					echo "<script>window.open('dashboard.php', '_self')</script>";

					$update = "update users set posts = 'yes' where user_id='$user_id'";
					$run_update = mysqli_query($con, $update);
				}

				exit();
			}
		}
			else{
				if($upload_image=='' && $content == ''){
					echo "<script>alert('Error Occured while uploading!')</script>";
					echo "<script>window.open('dashboard.php', '_self')</script>";
				}else{
					if($content==''){
						if (($category) == ''){
							echo "<script>alert('Please Select Category')</script>";
							echo "<script>window.open('dashboard.php', '_self')</script>";
						}

						else{
						move_uploaded_file($image_tmp, "imagepost/$upload_image.$random_number");
						$insert = "insert into posts (user_id, post_content,upload_image, category, post_date) values ('$user_id','No','$upload_image.$random_number', '$category' , NOW())";
						// $insert2 ="insert into categorypost (arch_id, upload_image) values('$category','$upload_image.$random_number')";
						$run = mysqli_query($con, $insert);
						// $run2 = mysqli_query($con, $insert2);
						

						if($run){
							echo "<script>alert('Your Post updated a moment ago!')</script>";
							echo "<script>window.open('dashboard.php', '_self')</script>";

							$update = "update users set posts = 'yes' where user_id ='$user_id'";
							$run_update = mysqli_query($con, $update);
						}

						exit();
					}
					}else{
						$insert = "insert into posts (user_id, post_content, post_date) values('$user_id','$content', NOW())";
						$run = mysqli_query($con, $insert);

						if($run){
							echo "<script>alert('Your Post updated a moment ago!')</script>";
							echo "<script>window.open('dashboard.php', '_self')</script>";

							$update = "update users set posts = 'yes' where user_id = '$user_id'";
							$run_update = mysqli_query($con, $update);
						}
					}
				}
			}
		}
	}
}

function get_posts(){
	global $con;
	global $user_id;
	$per_page = 10;
	

	if(isset($_GET['page'])){
		$page = $_GET['page'];
	}else{
		$page=1;
	}

	$start_from = ($page-1) * $per_page;

	$get_posts = "select * from posts ORDER by post_id DESC LIMIT $start_from, $per_page";


	$run_posts = mysqli_query($con, $get_posts);

	while($row_posts = mysqli_fetch_array($run_posts)){

		$post_id = $row_posts['post_id'];
		$user_id = $row_posts['user_id'];
		$content = substr($row_posts['post_content'], 0,100);
		$upload_image = $row_posts['upload_image'];
		$post_date = $row_posts['post_date'];
		$category = $row_posts['category'];
		

		$user = "select username, profpic from users where user_id ='$user_id' AND posts = 'yes'";
		$run_user = mysqli_query($con,$user);
		$row_user = mysqli_fetch_array($run_user);

		$user_name = $row_user['username'];
		$user_image = $row_user['profpic'];

		if($content=="No" && strlen($upload_image) >= 1){
			echo"
			<div class='row'>
            <div class='col-sm-3'>
            </div>
            <div id='posts' class='col-sm-6'>
			<div class='row'>
				<a class='del-menu' href='delete_post.php?post_id=$post_id' style='float: right';>
					<button class=btn-kebab>
					<i class='bx bxs-trash-alt' style='color:#4f3b8f'  ></i>
					</button> 
				</a>
		
                    <div class='col-sm-2'>
                        <div class='profpic'>
                            <p><img src='users/$user_image' alt='' class='img-circle' width='80px' height='80px' style='border-radius: 40px;'></p>
                        </div>
                        <div class='unmpost'>
                            <h3><a style='text-decoration: none; cursor:pointer; color: black;' href='profile.php?u_id=$user_id'>$user_name</a></h3>
                            <h4><small style='color: black;'>Updated a post on <strong>$post_date</strong></small></h4>
                            <h5><small style='color: black;'>Category : <strong>$category</strong></small></h5>
                        </div>
                    </div>
                    <div class='col-sm-4'>
                    </div>
                    <div class='col-row'>
                        <div class='col-sm-12'>
						<img id='posts-img' src='imagepost/$upload_image' alt=''>
                        </div>
                    </div><br>
					<a href='single.php?post_id=$post_id' style='float:right;'><button class='btn btn-info'>View Comments</button></a><br>
                </div>
                <div class='col-sm-3'>
                </div>
            </div>
        	</div><br><br>
			";
		}

		else if(strlen($content) >= 1 && strlen($upload_image) >= 1){
			echo"
			<div class='row'>
            <div class='col-sm-3'>
            </div>
            <div id='posts' class='col-sm-6'>
			<div class='row'>
				<a class='del-menu' href='delete_post.php?post_id=$post_id' style='float: right';>
					<button class=btn-kebab>
					<i class='bx bxs-trash-alt' style='color:#4f3b8f'  ></i>
					</button> 
				</a>
                    <div class='col-sm-2'>
                        <div class='profpic'>
                            <p><img src='users/$user_image' alt='' class='img-circle' width='80px' height='80px' style='border-radius: 40px;'></p>
                        </div>
                        <div class='unmpost'>
                            <h3><a style='text-decoration: none; cursor:pointer; color: #3897f0;' href='profile.php?u_id=$user_id'>$user_name</a></h3>
                            <h4><small style='color: black;'>Updated a post on <strong>$post_date</strong></small></h4>
                            <h5><small style='color: black;'>Category : <strong>$category</strong></small></h5>
                        </div>
                    </div>
                    <div class='col-sm-4'>
                    </div>
                    <div class='col-row'>
                        <div class='col-sm-12'>
                            <p>$content</p>
                            <img id='posts-img' src='imagepost/$upload_image' alt=''>
                        </div>
                    </div><br>
					<a href='single.php?post_id=$post_id' style='float:right;'><button class='btn btn-info'>View Comments</button></a><br>
                </div>
                <div class='col-sm-3'>
                </div>
            </div>
        	</div><br><br>
			";
		}

		else{
			echo"
			<div class='row'>
            <div class='col-sm-3'>
            </div>
            <div id='posts' class='col-sm-6'>
			<div class='row'>
				<a href='delete_post.php?post_id=$post_id' class='del-menu' style='float: right';>
					<button class=btn-kebab>
						<i class='bx bxs-trash-alt' style='color:#4f3b8f'  ></i>
					</button> 
				</a>
                    <div class='col-sm-2'>
                        <div class='profpic'>
                            <p><img src='users/$user_image' alt='' class='img-circle' width='80px' height='80px' style='border-radius: 40px;'></p>
                        </div>
                        <div class='unmpost'>
                            <h3><a style='text-decoration: none; cursor:pointer; color: black;' href='profile.php?u_id=$user_id'>$user_name</a></h3>
                            <h4><small style='color: black;'>Updated a post on <strong>$post_date</strong></small></h4>
                        </div>
                    </div>
                    <div class='col-sm-4'>
                    </div>
                    <div class='col-row'>
                        <div class='col-sm-12'>
                            <p>$content</p>
                        </div>
                    </div><br>
					<a href='single.php?post_id=$post_id' style='float:right;'><button class='btn btn-info'>View Comment</button></a><br>
                </div>
                <div class='col-sm-3'>
                </div>
            </div>
        	</div><br><br>
			";
		}
		
		include("delete_post.php");
	}
	include("pageset.php");
}

function archGallery(){
	global $con;

	$get_posts = "select * from archpost ORDER by img_id desc";
	$run_posts = mysqli_query($con, $get_posts);

$data = mysqli_fetch_array($run_posts);
    
    $arch_img = $data['upload_image'];
    $arch_id = $data['arch_id'];
    $img_id = $data['img_id'];

    if($arch_id = 1){
        echo "
        <div class='row'> ";

       $a = 0;
        while ($a <= strlen($img_id)){
            echo "
            <div class='column'>
                <img src='imagepost/$arch_img'>
            </div> 
            ";
            $img_id++;
            $a++;
        }
    }

}

function search_user(){
	global $con;

	if(isset($_POST['search_user_btn'])){
		$search_query = htmlentities($_POST['search_user']);
		$get_user = "select * from users where username like '%$search_query%'";
	}
	else{
		$get_user = "select * from users";
	}

	$run_user = mysqli_query($con, $get_user);
	while($row_user = mysqli_fetch_array($run_user)){
		$user_id = $row_user['user_id'];
		$user_name = $row_user['username'];
		$user_image = $row_user['profpic'];

		echo"
			<div class='row' id='sr'>
				<div class='col-sm-3'>
				</div>
				<div class='col-sm-6' id='result'>
					<div class='row' id='find_people'>
						<div class='col-sm-4' id='nameresult'>
							<a href='profile.php?u_id=$user_id'>
							<img src='users/$user_image' width='50px' height='50px' title='$user_name' style='float:left; ,margin=1px;'/>
							</a>
							<a style='text-decoration:none; cursor:pointer; color:#3897f0;' href='profile.php?u_id=$user_id'>
							<strong><h2>$user_name</h2></strong>
							</a>
							
						</div><br><br>
						<div class='col-sm-3'>
						</div>
					</div>
				</div>
				<div class='col-sm-4'>
				</div>
			</div><br>
		";
	}


}

function single_post(){

	if (isset($_GET['post_id'])){

		global $con;

		$get_id = $_GET['post_id'];
		$get_posts = "select * from posts where post_id='$get_id'";

		$run_posts = mysqli_query($con, $get_posts);

		$row_posts = mysqli_fetch_array($run_posts);

		$post_id = $row_posts['post_id'];
		$user_id = $row_posts['user_id'];
		$content = $row_posts['post_content'];
		$upload_image = $row_posts['upload_image'];
		$post_date = $row_posts['post_date'];
		$category = $row_posts['category'];

		$user = "select * from users where user_id = '$user_id' AND posts = 'yes'";

		$run_user = mysqli_query($con,$user);
		$row_user = mysqli_fetch_array($run_user);

		$user_name = $row_user['username'];
		$user_image = $row_user['profpic'];

		$user_com = $_SESSION['email'];
		$get_com = "select * from users where email='$user_com'";

		$run_com = mysqli_query($con, $get_com);
		$row_com = mysqli_fetch_array($run_com);

		$user_com_id = $row_com['user_id'];
		$user_com_name = $row_com['username'];

		if(isset($_GET['post_id'])){
			$post_id = $_GET['post_id'];
		}

		$get_posts = "select post_id from users where post_id = '$post_id'";
		$run_user = mysqli_query($con, $get_posts);
		
		$post_id = $_GET['post_id'];

		$post = $_GET['post_id'];
		$get_user = "select * from posts where post_id = '$post_id'";
		$run_user = mysqli_query($con, $get_user);
		$row = mysqli_fetch_array($run_user);

		$p_id = $row['post_id'];

		if($p_id != $post_id){
			echo "<script>alert('ERROR')</script>";
			echo "<script>window.open('dashboard.php', '_SELF')</script>";
		}else{
		
			if($content=="No" && strlen($upload_image) >= 1){
				echo"
				<div class='row'>
				<div class='col-sm-3'>
				</div>
				<div id='posts' class='col-sm-6'>
				<div class='row'>
					<a class='del-menu' href='delete_post.php?post_id=$post_id' style='float: right';>
						<button class=btn-kebab>
						<i class='bx bxs-trash-alt' style='color:#4f3b8f'  ></i>
						</button> 
					</a>
			
						<div class='col-sm-2'>
							<div class='profpic'>
								<p><img src='users/$user_image' alt='' class='img-circle' width='80px' height='80px' style='border-radius: 40px;'></p>
							</div>
							<div class='unmpost'>
								<h3><a style='text-decoration: none; cursor:pointer; color: black;' href='profile.php?u_id=$user_id'>$user_name</a></h3>
								<h4><small style='color: black;'>Updated a post on <strong>$post_date</strong></small></h4>
								<h5><small style='color: black;'>Category : <strong>$category</strong></small></h5>
							</div>
						</div>
						<div class='col-sm-4'>
						</div>
						<div class='col-row'>
							<div class='col-sm-12'>
							<img id='posts-img' src='imagepost/$upload_image' alt=''>
							</div>
						</div><br>
					
					</div>
					<div class='col-sm-3'>
					</div>
				</div>
				</div><br><br>
				";
			}
	
			else if(strlen($content) >= 1 && strlen($upload_image) >= 1){
				echo"
				<div class='row'>
				<div class='col-sm-3'>
				</div>
				<div id='posts' class='col-sm-6'>
				<div class='row'>
					<a class='del-menu' href='delete_post.php?post_id=$post_id' style='float: right';>
						<button class=btn-kebab>
						<i class='bx bxs-trash-alt' style='color:#4f3b8f'  ></i>
						</button> 
					</a>
						<div class='col-sm-2'>
							<div class='profpic'>
								<p><img src='users/$user_image' alt='' class='img-circle' width='80px' height='80px' style='border-radius: 40px;'></p>
							</div>
							<div class='unmpost'>
								<h3><a style='text-decoration: none; cursor:pointer; color: black' href='profile.php?u_id=$user_id'>$user_name</a></h3>
								<h4><small style='color: black;'>Updated a post on <strong>$post_date</strong></small></h4>
								<h5><small style='color: black;'>Category : <strong>$category</strong></small></h5>
							</div>
						</div>
						<div class='col-sm-4'>
						</div>
						<div class='col-row'>
							<div class='col-sm-12'>
								<p>$content</p>
								<img id='posts-img' src='imagepost/$upload_image' alt=''>
							</div>
						</div><br>
						
					</div>
					<div class='col-sm-3'>
					</div>
				</div>
				</div><br><br>
				";
			}

			else{
				echo"
				<div class='row'>
				<div class='col-sm-3'>
				</div>
				<div id='posts' class='col-sm-6'>
				<div class='row'>
					<a href='delete_post.php?post_id=$post_id' class='del-menu' style='float: right';>
						<button class=btn-kebab>
							<i class='bx bxs-trash-alt' style='color:#4f3b8f'  ></i>
						</button> 
					</a>
						<div class='col-sm-2'>
							<div class='profpic'>
								<p><img src='users/$user_image' alt='' class='img-circle' width='80px' height='80px' style='border-radius: 40px;'></p>
							</div>
							<div class='unmpost'>
								<h3><a style='text-decoration: none; cursor:pointer; color: black;' href='profile.php?u_id=$user_id'>$user_name</a></h3>
								<h4><small style='color: black;'>Updated a post on <strong>$post_date</strong></small></h4>
							</div>
						</div>
						<div class='col-sm-4'>
						</div>
						<div class='col-row'>
							<div class='col-sm-12'>
								<p>$content</p>
							</div>
						</div><br>
					</div>
					<div class='col-sm-3'>
					</div>
				</div>
				</div><br><br>
				";
			}
		} //else ending


		include('comments.php');
		
		echo"
		<div class='row com'>
		<div class='col-md-6 col-md-offset-3'>
		<div class='panel panel-info'>
		<div class='panel-body'>
		<form action='' method='post' class='form-inline' id='comment_form'>
		<textarea placeholder='Write your comment' class='pb-cmnt-textarea' name='comment' id='comment'></textarea>
		<button class='btn btn-info pull-right' name='reply'>Comment</button>
		</form>
		</div>
		</div>
		</div>
		</div>
		
		";
		

		if(isset($_POST['reply'])){
			$comment = htmlentities($_POST['comment']);

			if($comment == ""){
				echo"<script>alert('Enter your comment!')</script>";
				echo"<script>window.open('single.php?post_id=$post_id', '_self')</script>";
			}else{
				$insert = "insert into comments (post_id, user_id, comment, comment_author, date) values('$post_id', '$user_id', '$comment', '$user_com_name', NOW())";
				
				$run = mysqli_query($con, $insert);

				echo"<script>alert('Your Comment Added!')</script>";
				echo"<script>window.open('single.php?post_id=$post_id', '_self')</script>";
			}
		}

	}


}






// function searching(){
// 	global $con;

// 	//search
// 	$srch = "SELECT * FROM 'USER' WHERE 'NAME' LIKE ? ";
	
// 	$search = mysqli_query($con, $srch);
// 	$result = mysqli_fetch_all($search);

// 	if(isset($_POST['search'])){
// 		// require "search.php";
// 		if (count($result) > 0) {
// 			foreach ($result as $r){
// 				echo"<div>" . $r['name'] . " . " .  "</div>";
// 			}
// 		} else {echo "<div> No results found.</div>";}
// 	}
	
// }

?>