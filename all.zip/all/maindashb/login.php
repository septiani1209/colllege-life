<?php 
(include "log.php");
// session_start();

// session_start();

// error_reporting(0);

// if (isset($_SESSION['username'])) {
//     header("Location: ../Dashboard/index.html");
// }

// if (isset($_POST['submit'])) {
// 	$email = $_POST['email'];
// 	$password = md5($_POST['password']);

// 	$sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
// 	$result = mysqli_query($conn, $sql);
// 	if ($result->num_rows > 0) {
// 		$row = mysqli_fetch_assoc($result);
// 		$_SESSION['username'] = $row['username'];
// 		header("Location: ../Dashboard/index.html");
// 	} else {
// 		echo "<script>alert('Woops! Email or Password is Wrong.')</script>";
// 	}
// }

?>

<!-- Isi Html nya -->

<html>
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <link rel="stylesheet" href="logcss.css">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
      
   </head>
   <body>
      <header>
          <div class="slide-controls">
             <input type="radio" name="slide" id="login" checked>
             <input type="radio" name="slide" id="signup">
             <label for="login" class="slide login">Login</label>
             <label for="signup" class="slide signup">Register</label>
             <div class="slider-tab"></div>
          </div>
       </header>
       <!-- <div class="left-side">
           <img src="png/sally.png" alt="">
       </div> -->
        <div class="wrapper">
            <div class="title-text">
               <div class="title login">
                  Welcome Back
               </div>
               <div class="title signup">
                  Register
               </div>
            </div>
            <div class="form-container">
               <!-- <div class="slide-controls">
                  <input type="radio" name="slide" id="login" checked>
                  <input type="radio" name="slide" id="signup">
                  <label for="login" class="slide login">Login</label>
                  <label for="signup" class="slide signup">Signup</label>
                  <div class="slider-tab"></div>
               </div> -->
               <div class="form-inner">
                <form  method="post" class="login" name="login">
                    <div class="field">
                        <input type="text" placeholder="Email Address" name="email" required>
                    </div>
                    <div class="field">
                        <input type="password" placeholder="Password" name="password" required>
                    </div>
                    <div class="pass-link">
                        <a href="#">Forgot password?</a>
                    </div>
                    <div class="field btn">
                        <div class="btn-layer"></div>
                        <input type="submit" value="Login" name="submit">
					</div>
					<div class="signup-link">
                        Not a member? <a href="">Signup now</a>
					</div>
				</form>
                <?php logIn(); ?>
                <form method="post" class="signup" name="register">
                    <div class="field">
                        <input type="text" placeholder="Username" name="username" required>
                    </div>
                    <div class="field">
                        <input type="text" placeholder="Email" name="email" required>
                    </div>
                    <div class="field">
                        <input type="text" placeholder="Password" name="password" required>
                    </div>
                    <!-- <div class="field">
                        <input type="text" placeholder="Confirm Password" name="cpassword" required>
                    </div> -->
                    <div class="field btn">
                        <div class="btn-layer"></div>
                        <input type="submit" value="Signup" name="submitR">
					</div>
                <?php register(); ?>
				</form>
               </div>
            </div>
         </div>
         <script>
            const loginText = document.querySelector(".title-text .login");
            const loginForm = document.querySelector("form.login");
            const loginBtn = document.querySelector("label.login");
            const signupBtn = document.querySelector("label.signup");
            const signupLink = document.querySelector("form .signup-link a");
            signupBtn.onclick = (()=>{
              loginForm.style.marginLeft = "-50%";
              loginText.style.marginLeft = "-50%";
            });
            loginBtn.onclick = (()=>{
              loginForm.style.marginLeft = "0%";
              loginText.style.marginLeft = "0%";
            });
            signupLink.onclick = (()=>{
              signupBtn.click();
              return false;
            });
         </script>
    </body>
</html>