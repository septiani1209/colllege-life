<?php
include('connect.php');


function findUname(){
    global $con;
if (isset($_GET['submit'])){
    $title = $_GET['search'];
    $sql = "select * from users where username like '%$title%'";
    $exe = mysqli_query($con, $sql);
    if(mysqli_num_rows($exe) > 0){
        $count = 0;
        while($row = mysqli_fetch_assoc($exe)){
            $count++;
        }
    }
}
}
?>