<!DOCTYPE html>
<?php 
    include "show-data.php";
    include "update-data.php";
    // include "includes/function.php";
    include "header.php";

?>


<html>
    <head>
    <title> My Profile</title>
    <meta name="viewport" content="width-device-width,
    initial-scale-1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/prof.css">
    </head>

    <body>
        <section id="input-form">
            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <div class="form">
                    <input class="editfield" id="inpUsername" type="text" name="username" value="<?php echo $username;?>">
                </div>
                <div class="form">
                    <input class="editfield" id="inpNama" type="text" name="nama" placeholder="Nama">
                </div>
                <div class="form">
                    <input class="editfield" id="inpMajor" type="major" name="major" placeholder="Major">
                </div>
                <div class="form">
                    <input class="editfield" id="inpUniversity" type="university" name="university" placeholder="University">
                </div>
                <div class="form">
                    <input class="editfield" id="inpDateofbirth" type="dateofbirth" name="dateofbirth" placeholder="Date of Birth">
                </div>
                <div class="form">
                    <input class="editfield" id="inpEmail" type="email" name="email" placeholder="Email">
                </div>
                <div class="form">
                    <button id="open" type="submit" class="bg-purple" name="submit">🚀  ADD POST</button>
                    <!-- <input onclick="" type="submit" name="submit" value="SAVE" class="bg-purple"> -->
                </div>
            </form>
        </section>

        <script>
            var formMenu = document.getElementById("input-form");
            formMenu.style.display = "none";

            function editForm() {
                if (formMenu.style.display === "none") {
                    formMenu.style.display = "block";
                } else {
                    formMenu.style.display = "none";
                }

                var nama = document.getElementById("pNama").innerHTML;
                var major = document.getElementById("pMajor").innerHTML;
                var university = document.getElementById("pUniversity").innerHTML;
                var dateofbirth = document.getElementById("pDateofbirth").innerHTML;
                var email = document.getElementById("pEmail").innerHTML;

                document.getElementById("inpNama").value = nama;
                document.getElementById("inpMajor").value = major;
                document.getElementById("inpUniversity").value = university;
                document.getElementById("inpDateofbirth").value = dateofbirth;
                document.getElementById("inpEmail").value = email;
            }

            function simpanForm() {
                formMenu.style.display = "none"
                var nama = document.getElementById("inpNama").value;
                var major = document.getElementById("inpMajor").value;
                var university = document.getElementById("inpUniversity").value;
                var dateofbirth = document.getElementById("inpDateofbirth").value;
                var email = document.getElementById("inpEmail").value;

                document.getElementById("pName").innerHTML = nama;
                document.getElementById("pMajor").innerHTML = major;
                document.getElementById("pUniversity").innerHTML = university;
                document.getElementById("pDateofbirth").innerHTML = dateofbirth;
                document.getElementById("pEmail").innerHTML = email;
            }
        </script>
    </body>
</html>