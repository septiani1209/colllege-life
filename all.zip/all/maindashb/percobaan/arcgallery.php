<?php



   
$get_posts = "select * from archpost ORDER by img_id desc";

$run_posts = mysqli_query($con, $get_posts);

$data = mysqli_fetch_array($run_posts);
    
    $arch_img = $data['upload_image'];
    $arch_id = $data['arch_id'];
    $img_id = $data['img_id'];

    if($arch_id = 1){
        echo "
        <div class='row'> ";

       $a = 0;
        while ($a <= strlen($img_id)){
            echo "
            <div class='column'>
                <img src='imagepost/$arch_img'>
            </div> 
            ";
            $img_id++;
            $a++;
        }
    }


?>
