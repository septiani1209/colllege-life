<?php

$con = mysqli_connect("localhost","root","","college_life") or die("Connection was not established"); 

$sql="select name from user order by id desc";

	$hasil = mysqli_query($con,$sql);
	$no=0;
	while ($data = mysqli_fetch_array($hasil)) {
	$no++;
    

    echo $data["name"]; }
?>