<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <!-- My CSS -->
    <link href="stylesheet" href="style.css"><section id="editprofile">
    <div class="container">
      <div class="row text-center mb-3">
        <div class="col">
          <h2>Create your profile</h2>
        </div>
      </div>
      <div class="row justify-content-center">
         <div class="col-md-5">
           <form>
             <div class="mb-3">
               <label for="name" class="form-label"> Name </label>
               <input type="name" class="form-control" id="email1" aria-describedby="emailHelp">
               
             </div>
             <div class="mb-3">
               <label for="exampleInputEmail1" class="form-label">Major</label>
               <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
             
             </div>
             <div class="mb-3">
               <label for="exampleInputEmail1" class="form-label">University</label>
               <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
               
             </div>
             <div class="mb-3">
               <label for="exampleInputEmail1" class="form-label">Date of Birth</label>
               <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
             </div>
             <div class="mb-3">
               <label for="exampleInputEmail1" class="form-label">Email address</label>
               <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
               
             </div>
             <div class="mb-3">
               <label for="exampleInputEmail1" class="form-label">Phone Number</label>
               <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
               
             </div>
             <button type="submit text-center" class="btn btn-primary text-center">Save</button>
             <i class="far fa-save"></i>
           </form>
         </div>
      </div>
    </div>
  </section>