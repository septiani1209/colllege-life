<form method="post">
    <input type="text" name= "search" required/>
    <input type="submit" value="search"/>
</form>



<?php
$con = mysqli_connect("localhost","root","","college_life") or die("Connection was not established"); 

if(isset($_POST['search'])){
    require "search.php";
    if (count($result) > 0) {
        foreach ($result as $r){
            echo"<div>" . $r['name'] . " . " .  "</div>";
        }
    } else {echo "<div> No results found.</div>";}
}

//search
$srch = "SELECT * FROM 'USER' WHERE 'NAME' LIKE ? ";

$search = mysqli_query($con, $srch);
$data = mysqli_fetch_array($search);