<?php 
include("includes/function.php"); ?>

<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo "$user_name"; ?></title>
        <link rel="stylesheet" href="css/style.css">
        <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        
    </head>
    <body>
        <div class="row">
            <div class="col-sm-12">
                <center>
                    <h2>Find People</h2>
                </center><br><br>
                <div class="row">
                    <div class="col-sm-4">
                    </div>
                    <div class="col-sm-4">
                        <form action="" class="search_form" name="finduser">
                            <input type="text" name="search_user" id="" placeholder="Search">
                            <button class="btn btn-info" type="submit" name="search_user_btn">Search</button>
                        </form>
                    </div>
                    <div class="col-sm-4">
                    </div>
                </div><br><br>
                <?php search_user(); ?>
            </div>
        </div>
    </body>
</html>