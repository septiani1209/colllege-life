<div class='row'>
    <div class='col-md-6 col-md-offset-3'>
        <div class='panel panel-info'>
            <div class='panel-body'>
                <form action='' method='post' class='form-inline'>
                    <textarea placeholder='Write your comment' class='pb-cmnt-textarea' name='comment'></textarea>
                    <button class='btn btn-info pull-right' name='reply'>Comment</button>
                </form>
            </div>
        </div>
    </div>
</div>